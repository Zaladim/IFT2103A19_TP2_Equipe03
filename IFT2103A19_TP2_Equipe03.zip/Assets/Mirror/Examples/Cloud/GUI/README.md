# Cloud GUI

This folder contains an example of a List server canvas and scripts that can help set up a GUI.


## Other Examples

See `PongWithListServer` or `TanksWithListServer` for playable examples